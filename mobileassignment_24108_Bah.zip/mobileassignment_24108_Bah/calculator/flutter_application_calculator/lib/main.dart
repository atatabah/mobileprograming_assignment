import 'package:flutter/material.dart';

void main() {
  runApp(CalculatorApp());
}

class CalculatorApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Calculator(),
    );
  }
}

class Calculator extends StatelessWidget {
  Widget calcButton(String btnText, Color btnColor, Color textColor) {
    return Container(
      margin: EdgeInsets.all(10),
      child: ElevatedButton(
        onPressed: () {},
        style: ElevatedButton.styleFrom(
          backgroundColor: btnColor,  // Use backgroundColor instead of primary
          padding: EdgeInsets.symmetric(horizontal: 24, vertical: 20),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(30),
          ),
        ),
        child: Text(
          btnText,
          style: TextStyle(
            fontSize: 24,
            color: textColor,
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Calculator'),
        backgroundColor: Colors.blueGrey,
      ),
      backgroundColor: Colors.black,
      body: Column(
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              Padding(
                padding: EdgeInsets.all(24),
                child: Text(
                  '0',
                  style: TextStyle(
                    fontSize: 48,
                    color: Colors.white,
                  ),
                ),
              ),
            ],
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              calcButton('C', Colors.grey, Colors.black),
              calcButton('±', Colors.grey, Colors.black),
              calcButton('%', Colors.grey, Colors.black),
              calcButton('÷', Colors.orange, Colors.white),
            ],
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              calcButton('7', Colors.grey[850]!, Colors.white),
              calcButton('8', Colors.grey[850]!, Colors.white),
              calcButton('9', Colors.grey[850]!, Colors.white),
              calcButton('×', Colors.orange, Colors.white),
            ],
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              calcButton('4', Colors.grey[850]!, Colors.white),
              calcButton('5', Colors.grey[850]!, Colors.white),
              calcButton('6', Colors.grey[850]!, Colors.white),
              calcButton('-', Colors.orange, Colors.white),
            ],
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              calcButton('1', Colors.grey[850]!, Colors.white),
              calcButton('2', Colors.grey[850]!, Colors.white),
              calcButton('3', Colors.grey[850]!, Colors.white),
              calcButton('+', Colors.orange, Colors.white),
            ],
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              calcButton('0', Colors.grey[850]!, Colors.white),
              calcButton('0', Colors.grey[850]!, Colors.white),
              calcButton('.', Colors.grey[850]!, Colors.white),
              calcButton('=', Colors.orange, Colors.white),
            ],
          ),
        ],
      ),
    );
  }
}
